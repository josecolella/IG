//**************************************************************************
// Práctica 1
//
// Domingo Martin Perandres 2013
//
// GPL
//**************************************************************************

#include <GL/gl.h>
#include <vector>
#include "vertex.h"

using namespace std;

void draw_cube();

//void draw_vertices(vector< _vertex3f> &Vertices, vector< _vertex3ui > caras);

//void draw_lines(vector< _vertex3f> &Vertices, vector< _vertex3ui > caras);

//void draw_solid(vector< _vertex3f> &Vertices, vector< _vertex3ui > caras);

//void draw_changedColor(vector< _vertex3f > &Vertices, vector<_vertex3ui>caras);


