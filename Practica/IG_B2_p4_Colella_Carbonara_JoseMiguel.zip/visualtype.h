#ifndef _VISUAL_T_H_
#define _VISUAL_T_H_

enum visual_t {POINT=1, LINE, FILL, CHECKERED, ILUM_PLANO, ILUM_SOFT};
enum light_t {DIRECTIONAL=0, POSITIONAL};
#endif