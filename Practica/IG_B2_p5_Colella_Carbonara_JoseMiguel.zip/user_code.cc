//**************************************************************************
// Codigo del usuario
//
// Domingo Martin Perandres 2013
//
// GPL
//**************************************************************************

#include "user_code.h"
#include "file_ply_stl.h"
#include <stdlib.h>
#include <stdio.h>
#include <GL/glut.h>
#include <ctype.h>
#include <cmath>
#include <iostream>
//**************************************************************************
// Funcion para dibujar los vertices de un cubo unidad
//***************************************************************************

using namespace std;


